WITH month_spine AS (
  SELECT DISTINCT DATE_TRUNC('month', ordered_at)::DATE AS month_start
  FROM {{ ref('orders') }}
),
months AS (
  SELECT ms.month_start,
         (ms.month_start + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS month_end
  FROM month_spine ms
),
eligible AS (
  SELECT DISTINCT m.month_start, c.member_id
  FROM months m
  JOIN {{ ref('cards') }} c
    ON c.card_type IN ('悦享年卡', '家庭季卡')
   AND c.valid_from <= m.month_end
   AND c.valid_until > m.month_end
   AND (c.ended_at IS NULL OR c.ended_at > m.month_end)
),
agg AS (
  SELECT e.month_start, e.member_id,
         COUNT(DISTINCT o.order_id) AS valid_orders,
         SUM(o.paid_cents - o.refund_cents) AS net_sales_cents
  FROM eligible e
  JOIN {{ ref('valid_orders_base') }} o
    ON o.member_id = e.member_id
   AND DATE_TRUNC('month', o.ordered_at)::DATE = e.month_start
  GROUP BY e.month_start, e.member_id
)
SELECT month_start, member_id, valid_orders, net_sales_cents
FROM agg