WITH ranked AS (
  SELECT o.order_id, o.member_id, o.ordered_at, o.paid_cents, o.refund_cents,
         ROW_NUMBER() OVER (PARTITION BY o.member_id ORDER BY o.ordered_at ASC, o.order_id ASC) AS rn
  FROM {{ ref('valid_orders_base') }} o
)
SELECT order_id, member_id, ordered_at, paid_cents, refund_cents
FROM ranked WHERE rn = 1