SELECT member_id,
       DATE_TRUNC('month', ordered_at)::DATE AS month_start,
       COUNT(DISTINCT order_id) AS valid_orders
FROM {{ ref('valid_orders_base') }}
GROUP BY member_id, DATE_TRUNC('month', ordered_at)::DATE