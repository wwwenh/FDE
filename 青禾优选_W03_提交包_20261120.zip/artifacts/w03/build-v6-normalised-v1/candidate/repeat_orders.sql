WITH ranked AS (
  SELECT o.order_id, o.member_id, o.ordered_at,
         ROW_NUMBER() OVER (PARTITION BY o.member_id ORDER BY o.ordered_at ASC, o.order_id ASC) AS rn
  FROM {{ ref('valid_orders_base') }} o
)
SELECT order_id, member_id, ordered_at FROM ranked WHERE rn >= 2