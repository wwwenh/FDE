"""Deterministic comparison only; no model, database, or generated library access."""
import json, math, sys
REL_TOL=1e-9
ABS_TOL=1e-7

def number_equal(want,got):
    if type(want) not in (int,float) or type(got) not in (int,float): return False
    if not math.isfinite(want) or not math.isfinite(got): return False
    if type(want) is int: return want==got
    return math.isclose(want,got,rel_tol=REL_TOL,abs_tol=ABS_TOL)

def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False)

def compare(expected,actual):
    errors=[]
    def diff(path,want,got): errors.append({'path':path,'expected':want,'actual':got})
    if not isinstance(expected,dict) or not isinstance(actual,dict):
        return {'passed':False,'differences':['expected and actual must be objects']}
    for key in ['status','data_version','data_sha256','catalog_sha256']:
        if key in expected and actual.get(key)!=expected[key]: diff(key,expected[key],actual.get(key))
    if actual.get('status')!=expected.get('status') or expected.get('status')!='ok':
        return {'passed':not errors,'differences':errors}
    ei=expected.get('intent',{});ai=actual.get('intent',{})
    if not isinstance(ei,dict) or not isinstance(ai,dict):
        return {'passed':False,'differences':['intent must be an object']}
    for key in ['start','end']:
        if key not in ei or ai.get(key)!=ei[key]:diff('intent.'+key,ei.get(key),ai.get(key))
    for key in ['metrics','group_by','filters']:
        a=ei.get(key);b=ai.get(key)
        if not isinstance(a,list) or not isinstance(b,list): diff('intent.'+key,a,b);continue
        # AND filter ordering and metric ordering have no semantic effect.
        if sorted(map(canonical,a))!=sorted(map(canonical,b)):diff('intent.'+key,a,b)
    metrics=ei.get('metrics',[]); groups=ei.get('group_by',[])
    if not isinstance(metrics,list) or not isinstance(groups,list):
        return {'passed':False,'differences':errors+['invalid intent lists']}
    for side,obj in [('expected',expected),('actual',actual)]:
        cols=obj.get('columns');rows=obj.get('rows');units=obj.get('units')
        if not isinstance(cols,list) or any(not isinstance(c,str) for c in cols) or len(cols)!=len(set(cols)):
            errors.append({'path':side+'.columns','rule':'unique string column names required'});continue
        if set(cols)!=set(metrics+groups):errors.append({'path':side+'.columns','rule':'columns must match requested metrics and groups'})
        if not isinstance(rows,list) or any(not isinstance(row,list) or len(row)!=len(cols) for row in rows):
            errors.append({'path':side+'.rows','rule':'rectangular row arrays required'})
        if not isinstance(units,dict) or set(units)!=set(metrics):errors.append({'path':side+'.units','rule':'one unit for each metric required'})
    if errors:return {'passed':False,'differences':errors}
    if actual['units']!=expected['units']:diff('units',expected['units'],actual['units'])
    def index(obj,side):
        result={};cols=obj['columns']
        for row in obj['rows']:
            values=dict(zip(cols,row)); key=canonical([values[g] for g in groups])
            if key in result:errors.append({'path':side+'.rows','group':key,'rule':'duplicate group'})
            result[key]=values
        return result
    want=index(expected,'expected');got=index(actual,'actual')
    if want.keys()!=got.keys():diff('rows.groups',sorted(want),sorted(got))
    for key in want.keys() & got.keys():
        for m in metrics:
            a=want[key][m];b=got[key][m]
            equal=(b is None) if a is None else number_equal(a,b)
            if not equal:errors.append({'path':'rows.'+m,'group':key,'expected':a,'actual':b})
    return {'passed':not errors,'differences':errors}

if __name__=='__main__':
    try:
        data=json.load(sys.stdin);result=compare(data['expected'],data['actual'])
        # Invalid non-finite inputs must not leak non-JSON values into the response.
        print(json.dumps(result,ensure_ascii=False,allow_nan=False))
    except Exception as exc:
        print(json.dumps({'passed':False,'differences':[{'rule':'invalid input','error_type':type(exc).__name__}]}))
