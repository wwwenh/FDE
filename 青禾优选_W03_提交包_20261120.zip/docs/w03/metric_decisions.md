# W03 指标核定与构建记录（2026-11-20）

当前38项均已定义并通过独立问数验证；不是客户正式验收或经营收益结论。

## 采用依据

- 32项采用01/02/03客户材料；退款按原订单下单日期归属，金额整数分。首购先全覆盖排序再筛窗口，当前月内复购分母为当月有效购买账户。
- 六项付费月报采用小林MSG-05990的产品范围、陈姐MSG-05999的日期端点和多卡规则、04统计确认邮件的月底资格后取全月有效订单。等级与购卡金额不替代资格。
- ended_at空值按字段语义作未记录提前终止的工程转换，不冒充角色逐字确认。未知、覆盖外、零分母与已知零分开处理。

## 方法与失败迭代

- build-v1、v5超时；v2通过基础校验但补充实测发现归属门店编号多跳路径失败。
- Skill v0.2增加事实粒度不变的直接角色关联；v3被引用校验拦截，并发现原生引用/实体约束问题；v0.3补充约束，v4因多给SQL-only辅助表粒度键而失败；v0.4要求精确键集合并保留账户自身归属关系。
- build-v6使用明确thinking=disabled的同一真实模型，38项定义齐全但存在协议元数据问题。normalise_build.py按有限规则整理，原始响应、前后值及程序哈希保留。normalised-v1暴露月度默认时间绑定遗漏；v2仅对唯一已声明时间字段补默认绑定。
- 当前成功构建为build-v6-normalised-v2；原模型响应在build-v6。计算表达式和被引用SQL没有被手工修改；转换日志记录全部结构整理，无法安全整理时失败。完整复跑见本文末尾“构建与复跑入口”。
- 通过标准merge提升为固定library，再load到qinghe-small-v2、qinghe-large-v2。原课程47个引擎/工具/产品文件与原包逐字节一致；工作区保留旧库；本包保留其原构建及失败运行记录，不重复打包旧库。

## 实际验证

- 当前小样本完整Agent回归28/28，覆盖38指标、全部12维度目标以及日期、筛选、零/null和越界场景。规模完整回归4/4，含38项共同查询、归属门店多角色分组/筛选及改写问法；原规模10/10为旧库历史记录。
- 当前库17项结果副本错误注入/顺序检查通过；未知门店与未定义指标2项标准Agent负向控制通过；原聊天入口2轮实际查询与独立CSV核算匹配。
- 维度全覆盖不等于承诺任意指标×维度组合；已验证组合列于tests.json、tests-large.json，其他组合须按当前支持路径与政策另核。9项月度指标仍限制整月、全门店全渠道和跨月按月展示。


## 指标规则逐项对应

适用版本：SOW v0.6，2026-11-20。仅限指定合成测试数据；当前库SHA256：58dd40044996e20ea5b057aac7483e507410c83309e552b09d2d897277aff111。

## 可定位的规则目录

01、02、03、04、05分别指仓库materials/w03/中的《订单日报说明》《财务邮件》《会员运营周报》《本期统计确认邮件》《数据字典》。下面的章节名是原文定位；公式是据原文落字段的工程表达，不冒充角色逐字原话。

| 规则 | 明确定义及原文定位 |
| --- | --- |
| T | 05覆盖与日期字段：Asia/Shanghai，覆盖[2024-09-01,2026-09-01)；订单按ordered_at，注册按registered_at。查询窗口[start,end)，退款按原订单日期而非现金退款日（01退款金额、02首段）。 |
| F1 | 01创建订单数：全部订单，含取消，按order_id一次。 |
| F2 | 01支付订单数：status=paid，含全退。 |
| F3 | 01有效订单数、02首段：paid且paid_cents>refund_cents；取消、全退不算有效购买。 |
| F4 | 01取消订单数：status=cancelled。 |
| F5 | 01退款订单数/部分退款订单数/全额退款订单数：paid且退款>0；部分为0<退款<实付；全退为实付>0且退款=实付。 |
| F6 | 01实付/退款/净销售额/原价/优惠：仅paid，分别实付、累计退款、实付-退款、原价、原价-实付求和；退款不冲减优惠。一般净额按全部paid求和；付费月报明确按有效订单净额求和。 |
| F7 | 01购买会员数/退款会员数：对应有效购买/退款订单的member_id去重；CRM账户，不合并跨系统自然人。 |
| F8 | 01成交门店数：有效订单store_id去重；05区分orders.store_id与members.home_store_id，二者数值可以相等，不能加不等过滤。 |
| F9 | 01有效订单商品件数：有效订单quantity原始件数求和，不推算净退货件数。 |
| F10 | 02各比率章节：各自明确分子/分母，零分母未定义；05金额整数分，元展示÷100，比率原值为0–1。 |
| O1 | 03注册会员数：按注册日计账户，可按归属门店/等级分组。 |
| O2 | 03观测期首购/首单/后续购买：先在全测试覆盖内按账户将有效订单依ordered_at、order_id排序，再筛查询窗口；第一笔为首单，后续为第2笔及以后，非终身首购。 |
| O3 | 03三项月内指标：每自然月有效订单≥1的账户为购买账户，≥2为复购账户，复购率=后者/前者；仅整月、全门店，多月逐月展示；零分母未定义。当前交付还采用目录中全渠道限制，不承诺任意维度拆分。 |
| Q1 | 小林MSG-05990：本次总部月报仅悦享年卡、家庭季卡；联名卡即使收费也排除，体验卡排除。等级及购卡金额不替代资格，此范围不改其他报表。 |
| Q2 | 陈姐MSG-05999：valid_from≤判定日<valid_until，且提前终止日当天起无效，即ended_at为空或判定日<ended_at。空值按05可空字段映射为未记录提前终止，是工程解释。 |
| Q3 | 陈姐MSG-05999：按要求的历史判定日，只要存在一张纳入且有效的卡即有资格；按账户去重，其他卡到期不否定有效卡，多卡不放大订单。 |
| Q4 | 04首段及限制段：判定日=自然月最后一天，先选月末有资格账户再取当月全门店全渠道有效订单；不要求下单当天有资格；六项仅完整月、跨月逐月，不拆门店或渠道。 |

Q1来源：artifacts/w02/sources/W3-interview-ce15129e-9b0d-58bd-a62d-ec8ff4e81677-transcript.json。Q2/Q3来源：同目录W3-interview-63c9a5ee-d8a5-5520-b994-387855e58fc5-transcript.json。每条指标均适用T；不适用卡资格的指标明确标“—”，避免把本期付费月报规则扩散到全部指标。

## 逐指标对应与独立核对入口

金额基数单位分；账户计数不是自然人数。所有行另由large-all-38规模用例覆盖；下表小样本编号B1–B7分别为small-aug-bundle-1至7。

| 指标ID | 订单/运营规则 | 月末资格规则 | 计算及单位 | 小样本 |
| --- | --- | --- | --- | --- |
| order_count | F1 | — | 订单号计数；count | B1 |
| paid_order_count | F2 | — | paid订单数；count | B1 |
| valid_order_count | F3 | — | 有效订单数；count | B1 |
| cancelled_order_count | F4 | — | 取消订单数；count | B1 |
| refund_order_count | F2,F5 | — | 退款订单数；count | B1 |
| partial_refund_order_count | F2,F5 | — | 部分退款订单数；count | B1 |
| full_refund_order_count | F2,F5 | — | 全额退款订单数；count | B1 |
| payment_cents | F2,F6 | — | Σ实付；cents | B2 |
| refund_cents | F2,F6 | — | Σ累计退款；cents | B2 |
| net_sales_cents | F2,F6 | — | Σ(实付-退款)；cents | B2 |
| gross_cents | F2,F6 | — | Σ原价；cents | B2 |
| discount_cents | F2,F6 | — | Σ(原价-实付)；cents | B2 |
| buyer_count | F3,F7 | — | 有效购买账户去重；count | B3 |
| refund_buyer_count | F2,F5,F7 | — | 退款账户去重；count | B3 |
| selling_store_count | F3,F8 | — | 成交门店去重；count | B3 |
| valid_order_items | F3,F9 | — | Σ有效订单原始件数；count | B3 |
| avg_order_value | F2,F3,F6,F10 | — | net_sales_cents/valid_order_count；cents_per_order | B4 |
| avg_buyer_value | F2,F3,F6,F7,F10 | — | net_sales_cents/buyer_count；cents_per_member | B4 |
| purchase_frequency | F3,F7,F10 | — | valid_order_count/buyer_count；orders_per_member | B4 |
| refund_amount_rate | F2,F6,F10 | — | refund_cents/payment_cents；ratio | B4 |
| cancel_rate | F1,F4,F10 | — | cancelled_order_count/order_count；ratio | B4 |
| refund_order_rate | F2,F5,F10 | — | refund_order_count/paid_order_count；ratio | B4 |
| discount_rate | F2,F6,F10 | — | discount_cents/gross_cents；ratio | B4 |
| items_per_order | F3,F9,F10 | — | valid_order_items/valid_order_count；items_per_order | B4 |
| new_member_count | O1 | — | 注册日期内账户数；count | B5 |
| first_buyer_count | F3,F7,O2 | — | 首笔有效订单在窗口的账户数；count | B5 |
| first_order_sales_cents | F3,F6,O2 | — | 首笔有效订单净额合计；cents | B5 |
| first_order_count | F3,O2 | — | 首笔有效订单数；count | B5 |
| repeat_order_count | F3,O2 | — | 第2笔及以后有效订单数；count | B5 |
| monthly_buyer_count | F3,F7,O3 | — | 当月有效订单≥1账户数；count | B6 |
| monthly_repeat_buyer_count | F3,F7,O3 | — | 当月有效订单≥2账户数；count | B6 |
| monthly_repeat_rate | F3,F7,F10,O3 | — | monthly_repeat_buyer_count/monthly_buyer_count；ratio | B6 |
| monthly_paid_buyer_count | F3,F7 | Q1,Q2,Q3,Q4 | 合资格账户中当月有效购买≥1账户数；count | B7 |
| monthly_paid_order_count | F3 | Q1,Q2,Q3,Q4 | 合资格账户当月有效订单数；count | B7 |
| monthly_paid_sales_cents | F3,F6 | Q1,Q2,Q3,Q4 | 合资格账户当月有效订单净额合计；cents | B7 |
| monthly_paid_repeat_buyer_count | F3,F7 | Q1,Q2,Q3,Q4 | 合资格账户中当月有效购买≥2账户数；count | B7 |
| monthly_paid_repeat_rate | F3,F7,F10 | Q1,Q2,Q3,Q4 | monthly_paid_repeat_buyer_count/monthly_paid_buyer_count；ratio | B7 |
| monthly_paid_avg_order_value | F3,F6,F10 | Q1,Q2,Q3,Q4 | monthly_paid_sales_cents/monthly_paid_order_count；cents_per_order | B7 |

复核链：本表规则→business_model.md及生成library/metrics.yml/catalog.json→tests.json冻结期望→test-small-v3实际意图/SQL/行→确定性比较。reference_audit.py和reference_paid_audit.py从原始CSV独立计算，不读取被测SQL。六项资格边界逐账户手算见本文独立手算核对部分。没有把购卡实付计入商品订单收入。

## 测试范围与选例依据

适用SOW v0.6。证据是指定数据与指定问题上的回归，不是统计抽样推断；“代表”仅指覆盖已列明需求和高风险边界。28/28、4/4不意味着任意问法、任意月份、任意指标×维度组合或真实生产均正确。

## 数据与选择方法

课程固定干净合成数据，未自行按结果挑选账户或删去失败行。小样本全量20账户、48订单、3门店、22卡；规模全量30000账户、300000订单、24门店、38891卡。覆盖[2024-09-01,2026-09-01)，上海时区。小样本数据SHA256为8a295969ec24556ebd7f818506633919e71f840fc86488d53efc185f9768cfe6；规模为0074e7f764c63e836617aecb0e217aa3b5cc0cf9ede557179ad46b077dcf8ba8。两者当前库版本均为58dd40044996e20ea5b057aac7483e507410c83309e552b09d2d897277aff111。

选取理由：7组基础查询覆盖全部38个指标；7条原边界用例覆盖分组、多指标、零/null、缺日期和越界；14条补充用例覆盖12个维度目标、AND条件、历史首购、日期及解释。规模4条以全38项联合查询验证规模数据正确性，另取曾暴露故障的归属角色路径及改写问法。基础集合在执行前由原始CSV生成期望；补充用例针对已有失败与风险扩展，保留旧失败及测试版本，不据实际答案修改独立数值。具体报告不等于客户签字。

原始CSV仅本地核算；模型调用使用问题、目录及必要查询结果，不上传整份CSV。独立期望通过reference_audit.py/reference_paid_audit.py及prepare_supplemental.py等读取原始CSV获得，未读取被测SQL或复制Agent答案；输入冻结于artifacts/w03/test-inputs/。

## 关键卡边界为何有区分力

M00001两张有效卡检查去重；M00004/M00010于8/31到期、M00005/M00011于8/31提前终止检查右端不含；M00007/M00013于8/31生效检查左端含；M00012于9/1终止检查月底仍有效；M00014一张终止另一张有效检查“存在一张”而非“所有卡”。M00013的8/5订单检查先按月底资格再取全月，而非按订单日资格。M00002/M00018收费联名卡、体验卡及M00015无卡检查产品/等级/金额不混用。M00003/M00017有资格但仅全退/取消，检查资格账户8个与有效购买账户6个的区别。逐单数值见本文独立手算核对部分，不能用这6个账户推断真实会员数量。

## 逐例覆盖表

| 用例ID | 预期状态 | 选取理由及核查点 |
| --- | --- | --- |
| small-aug-bundle-1 | ok | 区分创建/支付/有效/取消/部分退款/全退的集合，防止把paid等同有效。 |
| small-aug-bundle-2 | ok | 区分实付、退款、净额、原价与优惠，检查金额分及退款归属。 |
| small-aug-bundle-3 | ok | 区分订单、账户、门店去重与原始商品件数。 |
| small-aug-bundle-4 | ok | 8个不同分子分母，防止错误分母及比率/百分数混用。 |
| small-aug-bundle-5 | ok | 注册时间与下单时间分离；覆盖期首购、首单金额与后续订单分开。 |
| small-aug-bundle-6 | ok | 购买≥1、复购≥2，分母为购买账户，不是注册账户。 |
| small-aug-bundle-7 | ok | 一次核对6项月末资格指标；结合卡边界账户核对存在性去重及全月取单。 |
| small-group-store-net-sales | ok | 成交门店拆分不能误用会员归属门店。 |
| small-two-metrics | ok | 两项指标共同问数，避免漏项或把净额当退款。 |
| small-zero-and-null | ok | 覆盖内无订单净额为0，而零分母退款占比为null。 |
| clarify-no-period | clarify | 缺日期需澄清，不默认一个查询月份。 |
| unsupported-outside-data | unsupported | 覆盖外不当作零。 |
| unsupported-paid-partial-month | unsupported | 付费月报非整月拒绝。 |
| unsupported-paid-store-filter | unsupported | 付费月报门店拆分/筛选拒绝。 |
| dims-trade-store | ok | 成交门店编号/名称/地区三个字段同时分组。 |
| dims-home-store | ok | 归属门店编号/名称/地区三个字段同时分组；复现并验证曾失败的角色路径。 |
| dims-member-tier | ok | 账户及等级分组，等级只作维度，不代替付费资格。 |
| dims-channel-status | ok | 渠道/状态联合分组，paid和cancelled不混淆。 |
| dims-daily | ok | 按日分组及日期键。 |
| dims-monthly | ok | 按月分组跨7/8月，不能混合月份。 |
| and-filter | ok | 门店与渠道AND筛选，防止只应用一项。 |
| last-day | ok | 8/31当天应纳入，窗口结束9/1不纳入。 |
| first-july | ok | 换月验证全历史先排序，防止在8月窗口内重新定义首购。 |
| unsupported-combined-monthly-rate | unsupported | 拒绝跨月复购率合成一个值。 |
| clarity-payment | ok | 整体查询不擅自分组，核对解释中的结束日。 |
| clarity-frequency | ok | 核对解释明确购买账户分母。 |
| clarity-time | ok | 核对解释时间边界与实际查询一致。 |
| registration-home-tier | ok | 注册事实以注册日计数，归属门店及等级分组。 |
| large-all-38 | ok | 全量30万订单接入下，38指标一次查询与独立CSV核算逐项对照。 |
| large-home-role-group | ok | 24个归属门店的编号/名称/地区分组，检查角色关联及聚合粒度。 |
| large-home-role-and-channel | ok | 归属门店+小程序AND筛选，核对筛选路径及结果。 |
| large-net-paraphrase | ok | 改写为扣除退款后的销售金额，检查自然语言映射。 |

## 12个维度目标的实际用例

| 维度 | 小样本用例 |
| --- | --- |
| home_store | dims-home-store, registration-home-tier |
| home_store__region | dims-home-store |
| home_store__store_name | dims-home-store |
| member | dims-member-tier |
| member__tier | dims-member-tier, registration-home-tier |
| metric_time__day | dims-daily |
| metric_time__month | dims-monthly |
| order__channel | dims-channel-status |
| order__status | dims-channel-status |
| store | small-group-store-net-sales, dims-trade-store |
| store__region | dims-trade-store |
| store__store_name | dims-trade-store |

38项与B1–B7对应见本文指标规则对照；large-all-38全部复核。逐例原始结果、查询与比较见artifacts/w03/test-small-v3及test-large-v2；每份测试问题和期望见customer/w03/tests.json及tests-large.json。解释另见本文解释核查部分。另有2条未知值负向查询、17项结果副本判定检查、2轮聊天实测，分别记录，不计入28或4而扩大通过率。

## 尚未证明的范围

不是随机抽样，无置信区间；并未穷举所有月份/同义句/组合。规模查询验证指定数据量下正确性，不构成并发、响应时限、真实脏数据、权限隔离或生产稳定性验收。后续新增组合或生产范围按变更流程补测试和依据。技术结果也不证明节省工时、复购改善或投资回报。

## 错误结果拒绝标准

适用SOW v0.6及当前库。依据分两层：本文指标规则对照的业务规则决定应该算什么；执行前冻结的原始CSV独立期望决定具体答案；customer/w03/judge.py执行确定性比较。不用模型判断对错，不比较SQL文本是否相同，也不把解释措辞相同当正确。

## “拒绝”的两种含义

1. 查询范围不成立：Agent返回clarify（缺必要信息）或unsupported（不支持/覆盖外），而非编造数值。测试将该状态与事前预期比较。缺日期为clarify；覆盖外、付费月报非整月/门店筛选、跨月合并复购率为unsupported。未知S99允许unsupported或clarify，是依据课程提示在执行前冻结的允许集合，实际为unsupported；目录没有的满意度要求unsupported。仅拒绝了请求，不等于查询计算成功。
2. 已返回结果不符合预期：判定程序返回passed=false并记录differences，即拒绝将该结果作为正确交付。HTTP402等error是执行失败；数值看似相同也不能算查询通过。绝不把“错误被判定程序识别”改写成“Agent原本没有错误”。

## 可执行的比较标准

| 检查项 | 通过条件与拒绝依据 |
| --- | --- |
| 状态 | 显式合法ok/clarify/unsupported/error且与本用例预期一致；本期正常查询预期ok，error不通过。ok仍携带code或error即拒绝。非ok用例按已冻结状态判定；不对不存在的数值作正确承诺。 |
| 版本 | 正常查询的data_version、data_sha256、catalog_sha256全部匹配冻结期望，错一个即拒绝。非ok用例不要求其没有返回的版本字段。 |
| 查询语义 | 正常查询start/end精确一致；metrics/group_by/filters作为无序集合内容比较，AND条件次序可变但条件不可漏或改。 |
| 结构与分组 | 列名唯一且恰好对应指标+分组；行必须矩形。按分组键对齐，遗漏、额外或重复分组拒绝。无分组也不能返回重复总计行。 |
| 单位 | 每指标恰有一单位且与期望相同；分/元、比率/百分数混用拒绝。 |
| 数值 | 期望为整数时数值精确相等，不容许小误差；Python实现允许数值相等的整型/浮点表示。期望为浮点时math.isclose，rel_tol=1e-9、abs_tol=1e-7。布尔、字符串、NaN和无穷不作为合法数字。 |
| 未定义 | 期望null必须实际null；null与0互换拒绝。覆盖外不按空集合输出零。 |
| 等价排布 | 行顺序、列顺序、指标顺序及AND筛选次序不影响语义时允许；值仍按指标和分组名对齐。 |

任一差异则整条用例失败，不采用部分指标正确抵消错误。比较记录保留路径、预期及实际；原始回答、意图、SQL和版本同档。自由文本解释不由上述数值比较覆盖，已按本文解释核查部分人工阅读；解释若错误仍需修订，不以数值通过掩盖。

## 17项实测判定检查

原件：artifacts/w03/judge-checks/real-current-v3/summary.json及相邻逐项记录。14项错误副本均被判定程序拒绝：metric、date、filter、wrong-group、missing-group、duplicate-group、unit、percentage、null-zero、value、error-with-correct-value、error-disguised-ok、ok-retains-error-code、version。3项正向控制original-correct、row-order、column-order均通过，共17/17符合预定判断。

这些是当前真实Agent结果的副本变更；error-disguised-ok使用保留的历史402记录。不是17次新模型查询，也不是声称Agent自然犯了14种错误。另2项真实负向查询见test-negative-values-v1/report.json；28小样本中的范围拒绝和澄清也均保留。基础24项人工构造自检为辅助，不替代真实结果检查。

## 留证与处理

交付方当前在本地仓库保留冻结问题/期望、原始响应、比较差异与修订版本。发现失败先记录，不改独立期望迎合答案；经来源核查确需改口径时走变更、重算期望并重测，前版保留。三方核查、归档交接及具体签收人见sow.md责任台账；判定通过不等于三方签收或预算批准。

## 独立手算核对

用途：用原始小样本CSV校准独立审核程序；不是Agent查询结果、客户验收或实际经营统计。数据版本 qinghe-w03-20260923-small。

规则依据：小林MSG-05990（产品）、陈姐MSG-05999（日期及多卡）、04_本期统计确认邮件.md（月末资格后取全月有效订单）。有效订单与退款规则依据01/02客户材料。

## 先核资格，再看有没有有效购买

8月31日有资格的账户为 M00001、M00003、M00007、M00012、M00013、M00014、M00016、M00017，共8个。资格账户总数不等于“月末付费会员购买人数”。M00003只有全额退款单；M00017为取消单和全额退款单，两者没有有效购买。

## 有效购买逐账户核对

| 账户 | 原订单 | 有效订单数 | 净销售额（分） |
| --- | --- | --- | --- |
| M00001 | O0000001、O0000002 | 2 | 10000+18000=28000 |
| M00007 | O0000011 | 1 | 3000 |
| M00012 | O0000027、O0000028 | 2 | 2200+2250=4450 |
| M00013 | O0000030、O0000031 | 2 | 2300+2350=4650 |
| M00014 | O0000033、O0000034 | 2 | 2400+2450=4850 |
| M00016 | O0000038 | 1 | 2600 |

购买人数6；有效订单10；净销售额47550分；复购人数4；复购率4/6=2/3；订单均额47550/10=4755分/单。

## 能区分错误算法的边界实例

- M00001有两张有效纳入卡，但账户只计一次，订单不翻倍。
- M00004、M00010计划到期日是8月31日，月末无资格；M00005、M00011提前终止日是8月31日，同样无资格。
- M00007、M00013于8月31日生效，月末有资格。M00013的8月5日订单也计入本期月报，因为本期约定先取月末有资格账户再统计全月有效订单，不按下单日资格筛选。
- M00014一张卡8月15日终止、另一张8月20日起有效，月末仍有资格；其8月5日订单同样应计入。
- M00012提前终止日为9月1日，不影响8月31日资格。
- M00002、M00018的收费联名卡不能因收了钱而纳入；体验卡也排除。M00015没有卡，不凭会员等级猜资格。

审核程序输出：artifacts/w03/reference/small-2026-08-38-v2.json。上述手算是独立于被测指标库的核对，不导入生成SQL，也不以Agent回答反推期望。

## 解释核查记录

核查对象为已完成的真实Agent结果：小样本22条成功解释、规模10条成功解释，以及原聊天入口2轮月报。未调用额外LLM裁判，未修改原始回答。数值判定与解释核查分别记录。

## 核查结论

- 客户与范围：所查均为青禾课程合成数据，没有借其他客户统计。规模问答覆盖全部38项指标；小样本后23条为HTTP402失败，不列为解释通过。
- 金额和比率：已检查分转元及ratio转百分数。原聊天8月付费月报为6个购买账户、10单、475.50元、4个复购账户、66.67%、47.55元/单；7月与8月分月说明，未相加为跨月人数。
- 关键业务含义：规模首购说明“观测期而非终身首购”；后续订单数与月内复购人数分开；商品件数为原始购买件数；退款按原订单日期；会员按CRM账户而非跨系统自然人。
- 实际分组：规模渠道分组及会员归属地区分组解释与意图和SQL一致。月报说明全门店全渠道，未声称支持门店拆分或自动名单触达。

## 需要进一步改善的表述（未记为解释全部通过）

1. 小样本实付金额回答首句用了“按订单成交门店汇总”，实际intent.group_by为空，后句虽说未按门店拆分，首句仍容易误导。建议明确“全部门店整体汇总，未分组”，后续以新查询核查，不改写原件。
2. 小样本购买频次回答称“平均每个会员账户”，公式随后正确写为有效订单数/购买会员数。建议始终称“每个有有效购买的账户”，防止误读为全部注册账户。
3. 部分回答只说“覆盖至9月1日”或“8月1日至9月1日”，未每次明确结束日不含。查询意图和SQL实际半开区间正确；后续需检查解释是否能更清楚表达边界。

这些是解释清晰度的待复验项，不能用数值通过抵消。原始回答和SQL均保存在对应test目录与chat-runs/qinghe-small-v1，当前未改标准问数引擎或把新文字冒充实际回答。

## 当前库复验（2026-11-20）

已完整阅读test-small-v3的28条实际成功/澄清/拒绝说明、test-large-v2的4条实际解释及当前原聊天入口2轮结果，并对照各自意图、SQL、行、单位和独立核算。没有调用LLM裁判，没有改写原答案。

- 当前clarity-payment明确整体未分组、结束日不含；clarity-frequency明确分母是有有效购买的账户而非全部注册账户；clarity-time明确8月1日至9月1日结束不含，初轮三处清晰度问题已在这些新问法下复验。初轮原件保留，不称为原答案已被修改。
- 零与未定义：5月净额0.00元、退款占比因零分母未定义；覆盖外9月拒绝，不当零；已列出零值分组与未列分组分开说明。
- 归属门店分组、AND筛选、注册门店/等级、逐日逐月、末日和观测期首购等解释与实际意图和数值一致。规模归属门店编号/名称/地区与成交角色没有混用。
- 小样本付费月报6个购买账户、10单、475.50元、4个复购账户、66.67%、47.55元/单，原聊天7月与8月分别列出，没有跨月加总人数。规模38项说明保留观测期、整数分换算和合成数据范围。
- 少数拒绝说明仍包含英文指标ID，属于可读性改进项；拒绝状态与原因符合当前限制。未将数值通过等同为经营收益或合同批准。

当前核查结论仅适用于已执行记录和问法，不承诺所有未来表述都正确。

## 构建与复跑入口

本项目采用课程标准问数内核、dbt、MetricFlow与DuckDB。学员侧实现为构建Skill、严格输出整理程序、独立CSV审核程序、测试集及确定性判定程序；没有另写问数引擎。

## 实际构建链路

1. `customer/w03/build-metrics/SKILL.md` v0.4提供六段生成方法；实际执行快照见各build目录的skill_used.md。
2. `build_with_profile.py`调用原课程builder.generate，仅为构建请求显式设置官方支持的thinking=disabled和JSON输出。原模型调用和trace保留，未修改课程builder或查询引擎。
3. `normalise_build.py`读取完整真实模型响应，执行有限、可追溯的协议整理，再调用原publish_candidate及所有确定性检查。本次成功构建目录是build-v6-normalised-v2，其上游真实模型响应在build-v6。
4. 通过课程merge单输入提升为固定library，再分别加载大小样本项目。旧库在工作区另存；本包保留原构建build-v2和所有失败构建，避免重复打包旧库。

## 输出整理的边界

程序只处理：显式写着无缺失事实的已定义指标备注；把实际材料引文从business_model_usage移到材料使用provenance；仅恢复Markdown标记且要求唯一匹配的连续原文；移除无任何语义模型引用的辅助SQL；把SQL-only辅助粒度声明移出semantic粒度契约；对缺默认绑定且仅有一个已声明时间维度的模型补绑定。

不改指标表达式、计数/金额公式、有效期端点、资格产品、分子分母或被引用SQL。不猜词句近义引用，不补缺失业务事实，不处理歧义时间绑定。超出有限规则立即失败。原始响应、每项整理前后值、转换程序哈希和来源均保存。

## 在新工程复跑

先按课程README安装锁定依赖，并在本机设置FDE_MODEL_URL、FDE_MODEL_NAME、FDE_MODEL_KEY。密钥不进入交付包。下面所有输出目录必须是新的。

```sh
.venv/bin/python customer/w03/build_with_profile.py --config customer/w03/build.json --output artifacts/w03/new-generation
# 完整response已取得，但遇上述可整理协议问题时：
.venv/bin/python customer/w03/normalise_build.py --config customer/w03/build.json --input-run artifacts/w03/new-generation --output artifacts/w03/new-converted
.venv/bin/python tools/w03.py merge --inputs artifacts/w03/new-converted --data materials/data/small --output artifacts/w03/new-library
.venv/bin/python tools/w03.py load --library artifacts/w03/new-library --data materials/data/small --project .runtime/new-small
```

若生成目录本身已经通过全部检查，可直接merge该目录。测试前用rebind_cases.py在同一数据快照上只更新库版本锁定；它拒绝不同数据快照，不能通过改期望掩盖差异。

```sh
.venv/bin/python customer/w03/rebind_cases.py --project .runtime/new-small --cases customer/w03/tests.json --output customer/w03/tests-new-library.json
.venv/bin/python tools/w03.py test --project .runtime/new-small --cases customer/w03/tests-new-library.json --output artifacts/w03/new-test --judge-command .venv/bin/python customer/w03/judge.py
```

`reference_audit.py`与`reference_paid_audit.py`只读取原始CSV，不读取生成库或SQL；`prepare_supplemental.py`和`prepare_large_regression.py`准备分组与边界独立期望。`native_check_cases.py`为零模型调用的已知意图诊断，明确不能替代完整Agent测试。最终逐例报告、错误注入与解释核查分别保存。
