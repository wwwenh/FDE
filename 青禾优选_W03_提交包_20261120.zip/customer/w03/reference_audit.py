"""Read only source CSVs; compute reference values without MetricFlow or generated SQL."""
from pathlib import Path
import csv,json,collections,hashlib
ROOT=Path(__file__).resolve().parents[2]
def audit(data,start='2026-08-01',end='2026-09-01'):
    def read(name):
        with (data/(name+'.csv')).open(newline='') as f:return list(csv.DictReader(f))
    all_orders=read('orders');members=read('members')
    for o in all_orders:
        for k in ['paid_cents','refund_cents','gross_cents','quantity']:o[k]=int(o[k])
    inside=lambda o:start<=o['ordered_at']<end
    valid=lambda o:o['status']=='paid' and o['paid_cents']>o['refund_cents']
    orders=[o for o in all_orders if inside(o)];paid=[o for o in orders if o['status']=='paid'];good=[o for o in orders if valid(o)]
    refunded=[o for o in paid if o['refund_cents']>0]
    vals={'order_count':len(orders),'paid_order_count':len(paid),'valid_order_count':len(good),
          'cancelled_order_count':sum(o['status']=='cancelled' for o in orders),'refund_order_count':len(refunded),
          'partial_refund_order_count':sum(0<o['refund_cents']<o['paid_cents'] for o in paid),
          'full_refund_order_count':sum(0<o['paid_cents']==o['refund_cents'] for o in paid),
          'payment_cents':sum(o['paid_cents'] for o in paid),'refund_cents':sum(o['refund_cents'] for o in paid),
          'net_sales_cents':sum(o['paid_cents']-o['refund_cents'] for o in paid),
          'gross_cents':sum(o['gross_cents'] for o in paid),'discount_cents':sum(o['gross_cents']-o['paid_cents'] for o in paid),
          'buyer_count':len({o['member_id'] for o in good}),'refund_buyer_count':len({o['member_id'] for o in refunded}),
          'selling_store_count':len({o['store_id'] for o in good}),'valid_order_items':sum(o['quantity'] for o in good)}
    pairs={'avg_order_value':('net_sales_cents','valid_order_count'),'avg_buyer_value':('net_sales_cents','buyer_count'),
           'purchase_frequency':('valid_order_count','buyer_count'),'refund_amount_rate':('refund_cents','payment_cents'),
           'cancel_rate':('cancelled_order_count','order_count'),'refund_order_rate':('refund_order_count','paid_order_count'),
           'discount_rate':('discount_cents','gross_cents'),'items_per_order':('valid_order_items','valid_order_count')}
    for key,(a,b) in pairs.items():vals[key]=vals[a]/vals[b] if vals[b] else None
    first={}
    for o in sorted((o for o in all_orders if valid(o)),key=lambda o:(o['ordered_at'],o['order_id'])):
        mid=o['member_id'];first.setdefault(mid,o)
    first_window=[o for o in first.values() if inside(o)]
    buyers=collections.Counter(o['member_id'] for o in good)
    vals.update(new_member_count=sum(start<=m['registered_at']<end for m in members),first_buyer_count=len(first_window),
                first_order_count=len(first_window),first_order_sales_cents=sum(o['paid_cents']-o['refund_cents'] for o in first_window),
                repeat_order_count=sum(o['order_id']!=first[o['member_id']]['order_id'] for o in good),
                monthly_buyer_count=len(buyers),monthly_repeat_buyer_count=sum(n>=2 for n in buyers.values()))
    vals['monthly_repeat_rate']=vals['monthly_repeat_buyer_count']/len(buyers) if buyers else None
    evidence={'valid_order_ids':[o['order_id'] for o in good],'first_order_ids':[o['order_id'] for o in first_window],
              'buyers_order_counts':dict(buyers),'csv_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*.csv'))}}
    return {'kind':'independent CSV reference, not Agent test result','start':start,'end':end,'metric_count':len(vals),'values':vals,'evidence':evidence,
            'basis':['01_订单日报说明.md','02_财务邮件.md','03_会员运营周报.md'],'paid_qualification_metrics':'excluded until interview facts confirmed'}
if __name__=='__main__':
    result=audit(ROOT/'materials/data/small');p=ROOT/'artifacts/w03/reference/small-2026-08-v1.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'metric_count':result['metric_count'],'values':result['values']},ensure_ascii=False))
