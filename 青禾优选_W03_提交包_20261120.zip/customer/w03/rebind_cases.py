"""Rebind only library-version metadata; refuse a different data snapshot."""
from pathlib import Path
import argparse, copy, hashlib, json

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', required=True)
    p.add_argument('--cases', required=True)
    p.add_argument('--output', required=True)
    a = p.parse_args()
    source, target = Path(a.cases), Path(a.output)
    if target.exists():
        raise ValueError('OUTPUT_ALREADY_EXISTS')
    dataset = json.loads((Path(a.project) / 'dataset.json').read_text())
    data_hash = hashlib.sha256(json.dumps({k: v for k, v in dataset.items() if k != 'library_sha256'}, sort_keys=True).encode()).hexdigest()
    original = json.loads(source.read_text())
    result = copy.deepcopy(original)
    for c in result:
        expected = c['expected']
        if expected['status'] != 'ok':
            continue
        if expected.get('data_version') != dataset['id'] or (expected.get('data_sha256') and expected['data_sha256'] != data_hash):
            raise ValueError('DIFFERENT_DATA_SNAPSHOT: recompute independent expectations first')
        expected.update(data_sha256=data_hash, catalog_sha256=dataset['library_sha256'])
    for before, after in zip(original, result):
        assert {k: v for k, v in before['expected'].items() if k not in ('data_sha256', 'catalog_sha256')} == {k: v for k, v in after['expected'].items() if k not in ('data_sha256', 'catalog_sha256')}
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(target), 'cases': len(result), 'independent_values_changed': False}))

if __name__ == '__main__':
    main()
