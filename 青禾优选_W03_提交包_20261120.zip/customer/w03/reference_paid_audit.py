"""Independent reference on raw CSV, using verified course interview rules."""
from pathlib import Path
import csv,json,collections,importlib.util
ROOT=Path(__file__).resolve().parents[2]
def calculate(data,start='2026-08-01',end='2026-09-01',qualification_day='2026-08-31'):
    spec=importlib.util.spec_from_file_location('base_audit',ROOT/'customer/w03/reference_audit.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
    result=base.audit(data,start,end)
    def read(name):
        with (data/(name+'.csv')).open(newline='') as f:return list(csv.DictReader(f))
    d=qualification_day
    eligible={c['member_id'] for c in read('cards') if c['card_type'] in ['悦享年卡','家庭季卡'] and c['valid_from']<=d<c['valid_until'] and (not c['ended_at'] or d<c['ended_at'])}
    orders=[o for o in read('orders') if o['member_id'] in eligible and start<=o['ordered_at']<end and o['status']=='paid' and int(o['paid_cents'])>int(o['refund_cents'])]
    counts=collections.Counter(o['member_id'] for o in orders);buyers=len(counts);repeat=sum(n>=2 for n in counts.values());n=len(orders)
    sales=sum(int(o['paid_cents'])-int(o['refund_cents']) for o in orders)
    result['values'].update(monthly_paid_buyer_count=buyers,monthly_paid_order_count=n,monthly_paid_sales_cents=sales,monthly_paid_repeat_buyer_count=repeat,monthly_paid_repeat_rate=repeat/buyers if buyers else None,monthly_paid_avg_order_value=sales/n if n else None)
    result['metric_count']=len(result['values']);result['paid_qualification_metrics']='local independent reference from verified transcript messages, not Agent test results'
    result['evidence']['paid_qualification']={'day':d,'eligible_accounts':sorted(eligible),'valid_order_ids':[o['order_id'] for o in orders],'account_order_counts':dict(counts),'sources':['ROLE-LIN MSG-05990','ROLE-CHEN MSG-05999','04_本期统计确认邮件.md'],'ended_at_empty':'no recorded early termination, from nullable field meaning'}
    return result
if __name__=='__main__':
    result=calculate(ROOT/'materials/data/small');p=ROOT/'artifacts/w03/reference/small-2026-08-38-v2.json'
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'metric_count':result['metric_count'],'net_sales_cents':result['values']['net_sales_cents'],'monthly_paid_sales_cents':result['values']['monthly_paid_sales_cents']}))
