"""Run two standard Agent negative controls with prior allowed status sets."""
from pathlib import Path
import sys, json, importlib.util
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'platform'))
from fde_product.metrics.agent import MetricsAgent

def main():
    out = ROOT / 'artifacts/w03/test-negative-values-v1'
    out.mkdir(exist_ok=False)
    cases = [
        {'id': 'unknown-store', 'question': '2026年8月青禾成交门店编号S99的净销售额是多少？请不要替换成其他门店编号。', 'expected_alternatives': [{'status': 'unsupported'}, {'status': 'clarify'}], 'source': 'S99 is absent from the fixed synthetic store dictionary; the course intent prompt permits unsupported or clarification for an unknown value, but never an invented zero.'},
        {'id': 'undefined-metric', 'question': '2026年8月青禾的会员满意度是多少？', 'expected_alternatives': [{'status': 'unsupported'}], 'source': 'Member satisfaction is absent from the confirmed 38-metric catalog; no numerical value may be fabricated.'},
    ]
    (out / 'cases-before-run.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('judge', ROOT / 'customer/w03/judge.py')
    judge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(judge)
    agent = MetricsAgent(ROOT / '.runtime/qinghe-small-v2', out / 'traces')
    results = []
    for c in cases:
        actual = agent.ask(c['question'])
        comparisons = [judge.compare(expected, actual) for expected in c['expected_alternatives']]
        results.append({**c, 'actual': actual, 'comparisons': comparisons, 'passed': any(x['passed'] for x in comparisons)})
    report = {'kind': 'standard Agent negative controls; allowed statuses frozen before queries', 'passed': all(c['passed'] for c in results), 'cases': results}
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'results': [{'id': c['id'], 'status': c['actual']['status'], 'reason': c['actual'].get('reason')} for c in results]}, ensure_ascii=False))

if __name__ == '__main__':
    main()
