from pathlib import Path
import json,csv,collections
r=Path(__file__).resolve().parents[2]
reference=json.loads((r/'artifacts/w03/reference/small-2026-08-38-v2.json').read_text())
targets=json.loads((r/'customer/w03/targets.json').read_text());cases=[]
units={t['id']:'count' for t in targets}
for t in targets:
 m=t['id']
 if m.endswith('_cents'):units[m]='cents'
 if m.endswith('_rate'):units[m]='ratio'
units.update(avg_order_value='cents_per_order',avg_buyer_value='cents_per_member',purchase_frequency='orders_per_member',items_per_order='items_per_order',monthly_paid_avg_order_value='cents_per_order')
def case(cid,question,metrics,start,end,rows,group=None,filters=None,source=''):
 return {'id':cid,'question':question,'expected':{'status':'ok','data_version':'qinghe-w03-20260923-small','intent':{'metrics':metrics,'start':start,'end':end,'group_by':group or [],'filters':filters or []},'columns':(group or [])+metrics,'rows':rows,'units':{m:units[m] for m in metrics}},'expected_source':source}
for t in targets:
 m=t['id'];value=reference['values'][m]
 cases.append(case('small-aug-'+m,'2026年8月，青禾全门店、全渠道的'+t['name']+'是多少？',[m],reference['start'],reference['end'],[[value]],source='依据01/02/03/04客户材料及小林MSG-05990、陈姐MSG-05999中与本指标相关的规则；从manifest锁定的小样本CSV逐记录核算，未读取被测库或SQL。复核程序 customer/w03/reference_audit.py、reference_paid_audit.py；参考值与订单明细 artifacts/w03/reference/small-2026-08-38-v2.json。单位遵循 docs/w03/contract.md；日期按下单/注册或指标定义归属，首单先全覆盖排序，付费资格先按月末判账户再取全月有效订单。'))
with (r/'materials/data/small/orders.csv').open(newline='') as f:orders=list(csv.DictReader(f))
by_store=collections.defaultdict(int)
for o in orders:
 if '2026-08-01'<=o['ordered_at']<'2026-09-01' and o['status']=='paid':by_store[o['store_id']]+=int(o['paid_cents'])-int(o['refund_cents'])
cases.append(case('small-group-store-net-sales','2026年8月青禾按成交门店编号分别列出净销售额。',['net_sales_cents'],'2026-08-01','2026-09-01',[[k,v] for k,v in sorted(by_store.items())],['store'],source='按01日报定义，从原CSV中逐笔选8月paid订单，按订单store_id累加paid-refund；不按会员归属门店分组。参考审核独立于生成库。'))
cases.append(case('small-two-metrics','2026年8月青禾全门店全渠道净销售额和退款金额分别是多少？',['net_sales_cents','refund_cents'],'2026-08-01','2026-09-01',[[reference['values']['net_sales_cents'],reference['values']['refund_cents']]],source='同独立小样本参考；两指标列允许无意义重排，但不能漏项或换单位。'))
# The supplied sample has no orders in May; assert this before choosing a null case.
assert not any('2026-05-01'<=o['ordered_at']<'2026-06-01' for o in orders)
cases.append(case('small-zero-and-null','2026年5月青禾全门店全渠道的净销售额和退款金额占比是多少？',['net_sales_cents','refund_amount_rate'],'2026-05-01','2026-06-01',[[0,None]],source='原始orders.csv在5月无订单，属于覆盖内；加总净额已知为0，退款/实付为零分母，按02财务邮件未定义为null，不可填0。'))
for cid,q,status,why in [
 ('clarify-no-period','青禾净销售额是多少？','clarify','未提供时段，按公开规则必须澄清。'),
 ('unsupported-outside-data','2026年9月青禾净销售额是多少？','unsupported','manifest覆盖终点2026-09-01不含，不能按零回答。'),
 ('unsupported-paid-partial-month','2026年8月1日至8月15日青禾月末付费会员购买人数是多少？','unsupported','04邮件六项月报只支持完整自然月。'),
 ('unsupported-paid-store-filter','2026年8月青禾成交门店S01的月末付费会员购买人数是多少？','unsupported','04邮件六项月报限全门店全渠道，不支持按门店筛选。')]:
 cases.append({'id':cid,'question':q,'expected':{'status':status},'expected_source':why})
(r/'customer/w03/tests.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(r/'artifacts/w03/startup/test_plan_v1.json').write_text(json.dumps({'status':'prepared, not executed against Qinghe Agent','cases':len(cases),'target_metrics':38,'data_version':'qinghe-w03-20260923-small','limitations':['当前仅8月基线覆盖及部分结构边界；仍需补齐全部日期、多卡、筛选、维度和规模回归','期望来自独立审核，不应以Agent实际输出修改期望'],'unit_policy':units},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'test_cases_prepared':len(cases),'metric_coverage':38,'status':'not yet run'}))
