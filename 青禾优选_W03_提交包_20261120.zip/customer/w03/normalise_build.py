"""Normalize explicit protocol-only contradictions, then use course validation.

Never change metric expressions or reachable SQL. Only fill a missing time
binding when exactly one declared time dimension makes it unambiguous. Raw live
model responses remain immutable. No model is called by this command.
"""
from pathlib import Path
import argparse, copy, hashlib, json, re, shutil, sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'platform'))
from fde_product.metrics.builder import publish_candidate
from fde_product.metrics.common import dump, new_output

def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()

def exact_markdown_span(quote, source):
    # Restore only presentation markers, never words, punctuation or whitespace.
    def clean(s):
        chars, positions = [], []
        for i, c in enumerate(s):
            if c not in '*`':
                chars.append(c)
                positions.append(i)
        return ''.join(chars), positions
    wanted, _ = clean(quote)
    text, positions = clean(source)
    starts = [m.start() for m in re.finditer(re.escape(wanted), text)] if wanted else []
    if len(starts) != 1:
        return None
    start = starts[0]
    return source[positions[start]:positions[start + len(wanted) - 1] + 1]

def normalise(raw, payload):
    result = copy.deepcopy(raw)
    changes = []
    defined = {m['name'] for m in result['metrics']}
    kept = []
    for item in result.get('unresolved', []):
        facts = item.get('missing_facts', [])
        explicitly_empty = bool(facts) and all(isinstance(f, str) and re.fullmatch(r'无(?:[（(].*[）)])?', f) for f in facts)
        if item.get('metric_id') in defined and explicitly_empty and item.get('reason', '').startswith('无需未决'):
            changes.append({'operation': 'remove_explicit_no-missing-facts_annotation', 'original': item})
        else:
            kept.append(item)
    result['unresolved'] = kept
    sources = {'business_model.md': payload['business_model'], **payload['materials']}
    for c in result['catalog']:
        for s in c['sources']:
            if s['file'] not in sources:
                raise ValueError('UNKNOWN_SOURCE_FILE:' + s['file'])
            if s['quote'] not in sources[s['file']]:
                fixed = exact_markdown_span(s['quote'], sources[s['file']])
                if fixed is None:
                    raise ValueError('NON_EXACT_CATALOG_QUOTE:' + c['id'])
                changes.append({'operation': 'restore_exact_markdown_span', 'location': 'catalog.' + c['id'], 'before': s['quote'], 'after': fixed})
                s['quote'] = fixed
    usage, material_usage = [], []
    for item in result.get('business_model_usage', []):
        q = item['quote']
        if q in payload['business_model']:
            usage.append(item)
            continue
        fixed = exact_markdown_span(q, payload['business_model'])
        if fixed is not None:
            changes.append({'operation': 'restore_exact_markdown_span', 'location': 'business_model_usage', 'before': q, 'after': fixed})
            item['quote'] = fixed
            usage.append(item)
            continue
        matches = [name for name, text in payload['materials'].items() if q in text]
        if matches:
            material_usage.append({**item, 'source_files': matches})
            changes.append({'operation': 'move_material_quote_to_material_usage_provenance', 'original': item, 'source_files': matches})
        else:
            raise ValueError('NON_EXACT_BUSINESS_USAGE_QUOTE')
    if not usage:
        raise ValueError('ACTUAL_BUSINESS_MODEL_USAGE_REQUIRED')
    result['business_model_usage'] = usage
    for sm in result['semantic_models']:
        if sm.get('measures') and not sm.get('defaults', {}).get('agg_time_dimension') and any(not m.get('agg_time_dimension') for m in sm['measures']):
            times = [d['name'] for d in sm['dimensions'] if d.get('type') == 'time']
            if len(times) != 1 or any(m.get('agg_time_dimension') not in (None, times[0]) for m in sm['measures']):
                raise ValueError('AMBIGUOUS_AGGREGATION_TIME:' + sm['name'])
            sm['defaults'] = {**sm.get('defaults', {}), 'agg_time_dimension': times[0]}
            changes.append({'operation': 'bind_single_declared_time_dimension', 'model': sm['name'], 'dimension': times[0], 'rule': 'only one predeclared time dimension; no business date or formula invented'})
    semantic_names = {m['name'] for m in result['semantic_models']}
    grains = result['grain_keys']
    missing = semantic_names - set(grains)
    extras = set(grains) - semantic_names
    if missing or not extras <= set(result.get('model_sql', {})):
        raise ValueError('UNSAFE_GRAIN_KEYS_REPAIR')
    for name in sorted(extras):
        changes.append({'operation': 'keep_sql_helper_grain_outside_semantic_contract', 'model': name, 'keys': grains.pop(name)})
    sqls = result.get('model_sql', {})
    roots = {re.fullmatch(r"ref\(['\"]([a-z][a-z0-9_]*)['\"]\)", m['model']).group(1) for m in result['semantic_models']}
    reachable, pending = set(), list(roots)
    while pending:
        name = pending.pop()
        if name in reachable:
            continue
        reachable.add(name)
        pending.extend(re.findall(r"\{\{\s*ref\(['\"]([a-z][a-z0-9_]*)['\"]\)\s*\}\}", sqls.get(name, '')))
    for name in sorted(set(sqls) - reachable):
        changes.append({'operation': 'omit_unreferenced_sql_helper', 'model': name, 'original_sql': sqls.pop(name)})
    assert result['metrics'] == raw['metrics']
    for before, after in zip(raw['semantic_models'], result['semantic_models']):
        assert {k: v for k, v in before.items() if k != 'defaults'} == {k: v for k, v in after.items() if k != 'defaults'}
        assert all(after.get('defaults', {}).get(k) == v for k, v in before.get('defaults', {}).items())
    assert all(sql == raw['model_sql'][name] for name, sql in result['model_sql'].items())
    return result, changes, material_usage

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--input-run', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    source = Path(args.input_run).resolve()
    out = new_output(args.output)
    cfg_path = Path(args.config).resolve()
    cfg = json.loads(cfg_path.read_text())
    payload = json.loads((source / 'input.json').read_text())
    raw = json.loads((source / 'response.json').read_text())
    trace = json.loads((source / 'trace.json').read_text())
    text = trace.get('reply', {}).get('content', '').strip()
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\s*|\s*```$', '', text)
    if trace.get('error') or json.loads(text) != raw:
        raise ValueError('LIVE_RESPONSE_PROVENANCE_MISMATCH')
    result, changes, material_usage = normalise(raw, payload)
    targets = {t['id'] for t in payload['targets']}
    defined = [m['name'] for m in result['metrics']]
    pending = [x['metric_id'] for x in result.get('unresolved', []) if x.get('metric_id')]
    if set(defined) | set(pending) != targets or set(defined) & set(pending) or len(defined) != len(set(defined)):
        raise ValueError('TARGET_COVERAGE_STILL_INVALID')
    if {c['id'] for c in result['catalog']} != set(defined):
        raise ValueError('CATALOG_STILL_INVALID')
    out.mkdir()
    for name in ['input.json', 'trace.json', 'skill_used.md']:
        shutil.copy2(source / name, out / name)
    dump(out / 'original_response.json', raw)
    dump(out / 'response.json', result)
    dump(out / 'normalisation.json', {'source_run': str(source), 'model_calls': 0, 'changes': changes, 'material_usage': material_usage, 'metric_expressions_changed': False, 'semantic_model_change_scope': 'missing default binding to a single already-declared time dimension only', 'reachable_sql_changed': False, 'converter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    dump(out / 'source_check.json', {'passed': True, 'errors': [], 'rule': 'exact source strings or unique markdown-only span restoration'})
    sources = {'business_model.md': payload['business_model'], **payload['materials']}
    dump(out / 'provenance.json', {'skill_sha256': sha((source / 'skill_used.md').read_text()), 'input_hashes': {k: sha(v) for k, v in sources.items()}, 'defined': defined, 'unresolved': result.get('unresolved', []), 'business_model_usage': result['business_model_usage'], 'material_usage': material_usage, 'conversion_source': str(source), 'conversion_log': 'normalisation.json', 'converter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    publish_candidate(result, cfg['scope'], payload['dimension_targets'], (cfg_path.parent / cfg['data']).resolve(), out)
    print(json.dumps({'output': str(out), 'defined': len(defined), 'unresolved': len(pending), 'protocol_changes': len(changes), 'checks_passed': True}, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError) as exc:
        print(json.dumps({'status': 'error', 'code': str(exc)}, ensure_ascii=False))
        raise SystemExit(2)
