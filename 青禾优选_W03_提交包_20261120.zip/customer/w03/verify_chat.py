from pathlib import Path
import json, importlib.util, sys

ROOT = Path(__file__).resolve().parents[2]
def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def main():
    run_name = sys.argv[1] if len(sys.argv) > 1 else 'qinghe-small-v1'
    ref = module('ref_paid', 'customer/w03/reference_paid_audit.py')
    judge = module('judge', 'customer/w03/judge.py')
    july = ref.calculate(ROOT / 'materials/data/small', '2026-07-01', '2026-08-01', '2026-07-31')
    august = ref.calculate(ROOT / 'materials/data/small')
    (ROOT / 'artifacts/w03/reference/small-2026-07-38-v1.json').write_text(json.dumps(july, ensure_ascii=False, indent=2) + '\n')
    tests = json.loads((ROOT / 'customer/w03/tests.json').read_text())
    units = {}
    for c in tests:
        units.update(c['expected'].get('units', {}))
    metrics = ['monthly_paid_buyer_count', 'monthly_paid_order_count', 'monthly_paid_sales_cents', 'monthly_paid_repeat_buyer_count', 'monthly_paid_repeat_rate', 'monthly_paid_avg_order_value']
    metadata = {k: tests[0]['expected'][k] for k in ['data_version', 'data_sha256', 'catalog_sha256']}
    checks = []
    for i in [1, 2]:
        p = ROOT / f'artifacts/w03/chat-runs/{run_name}/{i:02}-response.json'
        actual = json.loads(p.read_text())['result']['metric_query']
        group = [] if i == 1 else ['metric_time__month']
        rows = [[august['values'][m] for m in metrics]] if i == 1 else [[date] + [r['values'][m] for m in metrics] for date, r in [('2026-07-01 00:00:00', july), ('2026-08-01 00:00:00', august)]]
        expected = {'status': 'ok', **metadata, 'intent': {'metrics': metrics, 'start': '2026-08-01' if i == 1 else '2026-07-01', 'end': '2026-09-01', 'group_by': group, 'filters': []}, 'columns': group + metrics, 'rows': rows, 'units': {m: units[m] for m in metrics}}
        checks.append({'response_path': str(p.relative_to(ROOT)), 'expected_source': 'independent raw-CSV July and August reference calculations, not copied Agent values', 'expected': expected, 'comparison': judge.compare(expected, actual)})
    report = {'kind': 'local comparison of existing real chat results; no new Agent queries', 'model_calls': 0, 'passed': all(x['comparison']['passed'] for x in checks), 'checks': checks}
    (ROOT / f'artifacts/w03/chat-runs/{run_name}/independent_comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'comparisons': len(checks)}))
    assert report['passed']

if __name__ == '__main__':
    main()
