from pathlib import Path
import csv, json, collections, importlib.util
ROOT = Path(__file__).resolve().parents[2]

def main():
    def read(name):
        with (ROOT / 'materials/data/small' / (name + '.csv')).open(newline='') as f:
            return list(csv.DictReader(f))
    orders = read('orders')
    members = {x['member_id']: x for x in read('members')}
    stores = {x['store_id']: x for x in read('stores')}
    original = json.loads((ROOT / 'customer/w03/tests.json').read_text())
    meta = {k: original[0]['expected'][k] for k in ['data_version', 'data_sha256', 'catalog_sha256']}
    reference = json.loads((ROOT / 'artifacts/w03/reference/small-2026-08-38-v2.json').read_text())
    july = json.loads((ROOT / 'artifacts/w03/reference/small-2026-07-38-v1.json').read_text())
    cases = []
    def add(cid, question, metrics, rows, groups=None, start='2026-08-01', end='2026-09-01', filters=None):
        units = {'net_sales_cents': 'cents', 'payment_cents': 'cents', 'purchase_frequency': 'orders_per_member', 'order_count': 'count', 'first_buyer_count': 'count', 'new_member_count': 'count'}
        cases.append({'id': cid, 'question': question, 'expected': {'status': 'ok', **meta, 'intent': {'metrics': metrics, 'start': start, 'end': end, 'group_by': groups or [], 'filters': filters or []}, 'columns': (groups or []) + metrics, 'rows': rows, 'units': {m: units[m] for m in metrics}}, 'expected_source': 'Independent raw CSV grouping in customer/w03/prepare_supplemental.py; uses orders.member_id and the two distinct store roles from the dictionary. Net = paid minus refund for paid rows, cancelled contributes zero. Date labels use the native timestamp serialization, numerical values are not copied from Agent outputs.'})
    def group_values(keys, start='2026-08-01', end='2026-09-01'):
        sums = collections.defaultdict(int)
        for o in orders:
            if not start <= o['ordered_at'] < end:
                continue
            member = members[o['member_id']]
            store = stores[o['store_id']]
            home = stores[member['home_store_id']]
            values = {'store': o['store_id'], 'store__store_name': store['store_name'], 'store__region': store['region'], 'home_store': member['home_store_id'], 'home_store__store_name': home['store_name'], 'home_store__region': home['region'], 'member': o['member_id'], 'member__tier': member['tier'], 'order__channel': o['channel'], 'order__status': o['status'], 'metric_time__day': o['ordered_at'] + ' 00:00:00', 'metric_time__month': o['ordered_at'][:7] + '-01 00:00:00'}
            key = tuple(values[k] for k in keys)
            sums[key] += int(o['paid_cents']) - int(o['refund_cents']) if o['status'] == 'paid' else 0
        return [list(key) + [value] for key, value in sorted(sums.items())]
    groups = [
        ('trade-store', ['store', 'store__store_name', 'store__region'], '2026年8月青禾净销售额，请同时按成交门店编号、成交门店名称及成交地区分组列出。'),
        ('home-store', ['home_store', 'home_store__store_name', 'home_store__region'], '2026年8月青禾净销售额，请同时按会员归属门店编号、会员归属门店名称及会员归属地区分组列出。'),
        ('member-tier', ['member', 'member__tier'], '2026年8月青禾净销售额，请同时按CRM会员账户编号和会员等级分组列出。'),
        ('channel-status', ['order__channel', 'order__status'], '2026年8月青禾净销售额，请同时按订单渠道和订单状态分组列出。'),
        ('daily', ['metric_time__day'], '2026年8月青禾每天的净销售额分别是多少？请逐日列出有记录的日期。'),
    ]
    for cid, dims, question in groups:
        add('dims-' + cid, question, ['net_sales_cents'], group_values(dims), dims)
    add('dims-monthly', '2026年7月和8月青禾净销售额分别是多少？请按月列出。', ['net_sales_cents'], group_values(['metric_time__month'], '2026-07-01', '2026-09-01'), ['metric_time__month'], start='2026-07-01')
    amount = sum(int(o['paid_cents']) - int(o['refund_cents']) for o in orders if '2026-08-01' <= o['ordered_at'] < '2026-09-01' and o['store_id'] == 'S01' and o['channel'] == '小程序' and o['status'] == 'paid')
    add('and-filter', '2026年8月青禾成交门店编号S01且订单渠道为小程序的净销售额是多少？', ['net_sales_cents'], [[amount]], filters=[{'field': 'store', 'op': 'eq', 'value': 'S01'}, {'field': 'order__channel', 'op': 'eq', 'value': '小程序'}])
    add('last-day', '2026年8月31日当天青禾创建订单数是多少？', ['order_count'], [[sum(o['ordered_at'] == '2026-08-31' for o in orders)]], start='2026-08-31')
    add('first-july', '2026年7月青禾全门店全渠道观测期首购会员数是多少？', ['first_buyer_count'], [[july['values']['first_buyer_count']]], start='2026-07-01', end='2026-08-01')
    cases.append({'id': 'unsupported-combined-monthly-rate', 'question': '请给出2026年7月和8月青禾月内复购率的两个月合计一个值，不要按月拆分。', 'expected': {'status': 'unsupported'}, 'expected_source': '03周报要求月内指标跨月按月展示，不能合并复购人数及分母形成一个跨月月内复购率；原生策略也禁止该组合。'})
    add('clarity-payment', '2026年8月青禾不按门店或渠道分组，整体实付金额是多少？请明确是否分组，并说明统计结束日是否包含。', ['payment_cents'], [[reference['values']['payment_cents']]])
    add('clarity-frequency', '2026年8月青禾购买频次是多少？请明确分母是哪些账户，不要把购买账户说成全部注册账户。', ['purchase_frequency'], [[reference['values']['purchase_frequency']]])
    add('clarity-time', '请查询2026年8月青禾净销售额，并说明统计时间起止日和结束日是否包含。', ['net_sales_cents'], [[reference['values']['net_sales_cents']]])
    registrations = collections.Counter((m['home_store_id'], m['tier']) for m in members.values() if '2026-07-01' <= m['registered_at'] < '2026-08-01')
    add('registration-home-tier', '2026年7月青禾注册会员数，请同时按会员归属门店编号和会员等级分组列出。', ['new_member_count'], [list(key) + [n] for key, n in sorted(registrations.items())], ['home_store', 'member__tier'], start='2026-07-01', end='2026-08-01')
    cases[-1]['expected_source'] = '03会员运营周报明确注册会员按注册日统计并可按归属门店与等级分组；直接对members.csv按registered_at筛7月，再按home_store_id与tier计数。不是订单人数，不读取生成SQL。'
    path = ROOT / 'customer/w03/tests-supplemental.json'
    path.write_text(json.dumps(cases, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'prepared_cases': len(cases), 'dimension_ids_covered': sorted({d for c in cases for d in c['expected'].get('intent', {}).get('group_by', [])})}))

if __name__ == '__main__':
    main()
