from pathlib import Path
import copy, json, importlib.util

ROOT = Path(__file__).resolve().parents[2]

def main():
    spec = importlib.util.spec_from_file_location('judge', ROOT / 'customer/w03/judge.py')
    judge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(judge)
    items = []
    for name in ['test-small-v3/metric_test_report.json', 'test-large-v2/metric_test_report.json']:
        path = ROOT / 'artifacts/w03' / name
        report = json.loads(path.read_text())
        for c in report['cases']:
            c['_source_report'] = str(path.relative_to(ROOT))
            c['_source_kind'] = 'real Agent'
            items.append(c)
    previous_failure = next(c for c in json.loads((ROOT / 'artifacts/w03/test-small-v1/metric_test_report.json').read_text())['cases'] if c['actual'].get('code') == 'MODEL_HTTP_402')
    previous_failure['_source_report'] = 'artifacts/w03/test-small-v1/metric_test_report.json'
    previous_failure['_source_kind'] = 'real Agent error, historical'
    items.append(previous_failure)
    good = [c for c in items if c['comparison']['passed'] and c['actual']['status'] == 'ok']
    base = next(c for c in good if c['_source_kind'] == 'real Agent' and c['expected']['intent']['metrics'] == ['net_sales_cents'] and not c['expected']['intent']['group_by'])
    grouped = next(c for c in good if c['_source_kind'] == 'real Agent' and c['expected']['intent']['group_by'] and len(c['actual']['rows']) > 1)
    ratio = next(c for c in good if any(u == 'ratio' and c['actual']['rows'][0][c['actual']['columns'].index(m)] is not None and c['actual']['rows'][0][c['actual']['columns'].index(m)] > 0 for m, u in c['actual']['units'].items()))
    null = next(c for c in good if any(v is None for row in c['actual']['rows'] for v in row))
    failed = next(c for c in items if c['actual'].get('code') == 'MODEL_HTTP_402')
    out = ROOT / 'artifacts/w03/judge-checks/real-current-v3'
    out.mkdir(exist_ok=False)
    checks = []
    def check(name, c, mutate, want=False, expected=None):
        actual = copy.deepcopy(c['actual'])
        mutate(actual)
        result = judge.compare(expected or c['expected'], actual)
        record = {'kind': 'mutation of a result copy, not a new Agent query', 'source_report': c['_source_report'], 'source_kind': c['_source_kind'], 'original_case': c['id'], 'original_trace': c['actual'].get('trace_id'), 'expected_passed': want, 'comparison': result, 'mutated_actual': actual}
        (out / (name + '.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        checks.append({'id': name, 'source_kind': c['_source_kind'], 'passed': result['passed'] == want})
    check('original-correct', base, lambda a: None, True)
    check('metric', base, lambda a: a['intent'].__setitem__('metrics', ['payment_cents']))
    check('date', base, lambda a: a['intent'].__setitem__('end', '2026-08-31'))
    check('filter', base, lambda a: a['intent'].__setitem__('filters', [{'field': 'store', 'op': 'eq', 'value': 'S01'}]))
    check('wrong-group', grouped, lambda a: a['intent'].__setitem__('group_by', []))
    check('missing-group', grouped, lambda a: a['rows'].pop())
    check('duplicate-group', grouped, lambda a: a['rows'].append(copy.deepcopy(a['rows'][0])))
    check('unit', base, lambda a: a['units'].__setitem__('net_sales_cents', 'yuan'))
    def percentage(a):
        for m, u in a['units'].items():
            i = a['columns'].index(m)
            if u == 'ratio' and a['rows'][0][i] is not None and a['rows'][0][i] > 0:
                a['rows'][0][i] *= 100
                return
        raise ValueError('positive ratio required')
    check('percentage', ratio, percentage)
    def nullzero(a):
        for row in a['rows']:
            for i, v in enumerate(row):
                if v is None:
                    row[i] = 0
                    return
    check('null-zero', null, nullzero)
    check('value', base, lambda a: a['rows'][0].__setitem__(0, a['rows'][0][0] + 1))
    check('error-with-correct-value', base, lambda a: a.__setitem__('status', 'error'))
    check('error-disguised-ok', failed, lambda a: a.__setitem__('status', 'ok'), expected={'status': 'error'})
    check('ok-retains-error-code', base, lambda a: a.__setitem__('code', 'MODEL_HTTP_402'))
    check('version', base, lambda a: a.__setitem__('data_version', 'wrong-version'))
    check('row-order', grouped, lambda a: a['rows'].reverse(), True)
    def reorder_columns(a):
        a['columns'].reverse()
        for row in a['rows']:
            row.reverse()
    check('column-order', grouped, reorder_columns, True)
    summary = {'all_passed': all(c['passed'] for c in checks), 'total': len(checks), 'checks': checks, 'limitations': ['all successful source results are real Agent results on the current library; error-disguise uses a preserved historical 402 error', 'injections are result-copy mutations, not new Agent queries or actual Agent mistakes']}
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False))
    assert summary['all_passed']

if __name__ == '__main__':
    main()
