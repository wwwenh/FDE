from pathlib import Path
import json, csv, collections
ROOT = Path(__file__).resolve().parents[2]

def main():
    previous = json.loads((ROOT / 'customer/w03/tests-large.json').read_text())
    reference = json.loads((ROOT / 'artifacts/w03/reference/large-2026-08-38-v1.json').read_text())
    targets = json.loads((ROOT / 'customer/w03/targets.json').read_text())
    units = {}
    for c in previous:
        units.update(c['expected'].get('units', {}))
    meta = {k: previous[0]['expected'][k] for k in ['data_version', 'data_sha256', 'catalog_sha256']}
    def read(name):
        with (ROOT / 'materials/data/large' / (name + '.csv')).open(newline='') as f:
            return list(csv.DictReader(f))
    members = {m['member_id']: m for m in read('members')}
    stores = {s['store_id']: s for s in read('stores')}
    grouped = collections.defaultdict(int)
    filtered = 0
    for o in read('orders'):
        if not '2026-08-01' <= o['ordered_at'] < '2026-09-01':
            continue
        home = stores[members[o['member_id']]['home_store_id']]
        key = (home['store_id'], home['store_name'], home['region'])
        net = int(o['paid_cents']) - int(o['refund_cents']) if o['status'] == 'paid' else 0
        grouped[key] += net
        if key[0] == 'S01' and o['channel'] == '小程序':
            filtered += net
    cases = []
    def add(cid, q, metrics, rows, groups=None, filters=None):
        cases.append({'id': cid, 'question': q, 'expected': {'status': 'ok', **meta, 'intent': {'metrics': metrics, 'start': '2026-08-01', 'end': '2026-09-01', 'group_by': groups or [], 'filters': filters or []}, 'columns': (groups or []) + metrics, 'rows': rows, 'units': {m: units[m] for m in metrics}}, 'expected_source': 'Numerical values remain the independently frozen large CSV references, not new Agent output. Grouping/filtering uses orders.member_id -> members.home_store_id -> stores, preserving cancelled zero rows. Built by prepare_large_regression.py. No generated SQL is imported.'})
    metrics = [t['id'] for t in targets]
    add('large-all-38', '2026年8月青禾全门店全渠道，请分别给出以下指标，不按门店或渠道分组：' + '、'.join(t['name'] for t in targets) + '。', metrics, [[reference['values'][m] for m in metrics]])
    add('large-home-role-group', '2026年8月青禾净销售额，请同时按会员归属门店编号、会员归属门店名称和会员归属地区分组。', ['net_sales_cents'], [list(k) + [v] for k, v in sorted(grouped.items())], ['home_store', 'home_store__store_name', 'home_store__region'])
    add('large-home-role-and-channel', '2026年8月青禾会员归属门店编号为S01，并且订单渠道为小程序的净销售额是多少？', ['net_sales_cents'], [[filtered]], filters=[{'field': 'home_store', 'op': 'eq', 'value': 'S01'}, {'field': 'order__channel', 'op': 'eq', 'value': '小程序'}])
    add('large-net-paraphrase', '2026年8月青禾全部门店、全部渠道，扣除退款后的销售金额合计是多少？', ['net_sales_cents'], [[reference['values']['net_sales_cents']]])
    (ROOT / 'customer/w03/tests-large-regression.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'cases_prepared': len(cases), 'metrics_covered': len(metrics), 'status': 'not yet run'}))

if __name__ == '__main__':
    main()
