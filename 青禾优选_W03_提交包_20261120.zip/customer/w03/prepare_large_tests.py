from pathlib import Path
import json,csv,collections,importlib.util
ROOT=Path(__file__).resolve().parents[2]
def main():
    spec=importlib.util.spec_from_file_location('paid_ref',ROOT/'customer/w03/reference_paid_audit.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
    data=ROOT/'materials/data/large';result=ref.calculate(data)
    out=ROOT/'artifacts/w03/reference/large-2026-08-38-v1.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    small=json.loads((ROOT/'customer/w03/tests.json').read_text());units={}
    for c in small:units.update(c['expected'].get('units',{}))
    names={x['id']:x['name'] for x in json.loads((ROOT/'customer/w03/targets.json').read_text())}
    groups=[['order_count','paid_order_count','valid_order_count','cancelled_order_count','refund_order_count','partial_refund_order_count','full_refund_order_count'],['payment_cents','refund_cents','net_sales_cents','gross_cents','discount_cents'],['buyer_count','refund_buyer_count','selling_store_count','valid_order_items'],['avg_order_value','avg_buyer_value','purchase_frequency','refund_amount_rate','cancel_rate','refund_order_rate','discount_rate','items_per_order'],['new_member_count','first_buyer_count','first_order_sales_cents','first_order_count','repeat_order_count'],['monthly_buyer_count','monthly_repeat_buyer_count','monthly_repeat_rate'],['monthly_paid_buyer_count','monthly_paid_order_count','monthly_paid_sales_cents','monthly_paid_repeat_buyer_count','monthly_paid_repeat_rate','monthly_paid_avg_order_value']]
    assert {m for g in groups for m in g}==set(names)
    cases=[]
    def add(cid,q,metrics,rows,group=None,filters=None,source=''):
        cases.append({'id':cid,'question':q,'expected':{'status':'ok','data_version':'qinghe-w03-20260923-large','intent':{'metrics':metrics,'start':'2026-08-01','end':'2026-09-01','group_by':group or [],'filters':filters or []},'columns':(group or [])+metrics,'rows':rows,'units':{m:units[m] for m in metrics}},'expected_source':source})
    for i,metrics in enumerate(groups,1):
        add('large-aug-bundle-'+str(i),'2026年8月，青禾全门店全渠道请分别给出以下指标：'+'、'.join(names[m] for m in metrics)+'。',metrics,[[result['values'][m] for m in metrics]],source='独立审核 customer/w03/reference_paid_audit.py（引用reference_audit.py），原始large CSV及manifest；同原文业务规则逐记录计算，不导入指标库或SQL。参考结果和原始订单/资格明细 artifacts/w03/reference/large-2026-08-38-v1.json。金额为分，按订单原日期；首购先全覆盖排序，月报先月末账户资格再取整月有效单。')
    def read(name):
        with (data/(name+'.csv')).open(newline='') as f:return list(csv.DictReader(f))
    stores={s['store_id']:s for s in read('stores')};members={m['member_id']:m for m in read('members')}
    channels=collections.defaultdict(int);regions=collections.defaultdict(int)
    for o in read('orders'):
        if '2026-08-01'<=o['ordered_at']<'2026-09-01' and o['status']=='paid':
            net=int(o['paid_cents'])-int(o['refund_cents']);channels[o['channel']]+=net
            regions[stores[members[o['member_id']]['home_store_id']]['region']]+=net
    add('large-channel-net','2026年8月青禾按订单渠道分别列出净销售额。',['net_sales_cents'],[[k,v] for k,v in sorted(channels.items())],['order__channel'],source='逐笔large原订单paid-refund，按orders.channel分组；归原订单下单日期，不是退款发生日。')
    add('large-home-region-net','2026年8月青禾按会员归属地区分别列出净销售额。',['net_sales_cents'],[[k,v] for k,v in sorted(regions.items())],['home_store__region'],source='逐笔large paid订单净额，依orders.member_id→members.home_store_id→stores.region，明确不是成交地区。字典提供关联；独立Python审核，不导入库。')
    add('large-channel-filter','2026年8月青禾订单渠道为小程序的净销售额是多少？',['net_sales_cents'],[[channels['小程序']]],filters=[{'field':'order__channel','op':'eq','value':'小程序'}],source='同上独立逐笔channel净额，取小程序一项；不是全门店全渠道汇总。')
    (ROOT/'customer/w03/tests-large.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'independent_metrics':len(result['values']),'large_test_cases':len(cases),'net_sales_cents':result['values']['net_sales_cents'],'paid_buyers':result['values']['monthly_paid_buyer_count'],'status':'reference computed; Agent not run'},ensure_ascii=False))
if __name__=='__main__':main()
