from pathlib import Path
import os, subprocess, json, urllib.request, socket, shutil, sys

ROOT = Path(__file__).resolve().parents[2]
os.chdir(ROOT)
os.environ['FDE_MODEL_PROFILE'] = 'deepseek-json'
os.environ['FDE_MODEL_TIMEOUT'] = '240'
with socket.socket() as sock:
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
proc = subprocess.Popen(['.venv/bin/python', 'tools/product.py', 'start', '--home', '.runtime/product', '--port', str(port)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
out = ROOT / sys.argv[1]
out.mkdir(exist_ok=False)
try:
    while True:
        line = proc.stdout.readline()
        if line.startswith('Product UI:'):
            break
        if not line and proc.poll() is not None:
            raise RuntimeError('Product did not start')
    session = None
    questions = [
        '2026年8月青禾全门店全渠道的月末付费会员购买人数、有效订单数、净销售额、复购人数、复购率和订单均额分别是多少？这里六项均指月末付费会员月报。',
        '请按月分别列出2026年7月和8月的上述六项付费会员月报指标。',
    ]
    summaries = []
    for i, question in enumerate(questions, 1):
        body = {'text': question, 'session_id': session, 'action_mode': False}
        req = urllib.request.Request(f'http://127.0.0.1:{port}/api/run', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', 'X-FDE-Client': 'local-ui'})
        with urllib.request.urlopen(req, timeout=300) as response:
            result = json.loads(response.read())
        session = result.get('session_id')
        (out / f'{i:02}-request.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n')
        (out / f'{i:02}-response.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        inner = result.get('result', {})
        query = inner.get('metric_query', {})
        trace = query.get('trace_id')
        if trace:
            shutil.copytree(ROOT / '.runtime/product/metric-runs' / trace, out / trace)
        summaries.append({'question': question, 'status': result.get('status'), 'metric_status': query.get('status'), 'rows': query.get('rows'), 'columns': query.get('columns'), 'answer': query.get('answer'), 'trace_id': trace})
    print(json.dumps(summaries, ensure_ascii=False))
finally:
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
