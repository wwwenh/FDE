"""Run the unchanged course builder with an explicit provider thinking toggle."""
from pathlib import Path
import argparse, json, sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'platform'))
from fde_product.models import CompatibleModel, ModelError
from fde_product.metrics.builder import generate

class JsonBuildModel(CompatibleModel):
    def _payload(self, messages, tools):
        payload = super()._payload(messages, tools)
        payload['thinking'] = {'type': 'disabled'}
        return payload

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    model = JsonBuildModel(request_profile='json-object', max_tokens=32768, retry_max_tokens=65536, timeout=240, retry_timeout=240)
    try:
        result = generate(args.config, args.output, model=model)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ModelError, ValueError, OSError) as exc:
        print(json.dumps({'status': 'error', 'code': getattr(exc, 'code', str(exc))}, ensure_ascii=False))
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
